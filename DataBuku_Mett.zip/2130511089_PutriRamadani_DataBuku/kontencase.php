<?php
// if(empty($_GET['page'])) header("Location: index.php");
?>

<!DOCTYPE html>
<html>
  <div class="col-sm-6 col-lg-3">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex align-items-center">
                      <div class="subheader">Menu CASE </div>
                      <div class="ms-auto lh-1">
                        <div class="dropdown">
                          <a class="dropdown-toggle text-muted" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Detil</a>
                          <div class="dropdown-menu dropdown-menu-end" style="position: absolute; inset: 0px 0px auto auto; margin: 0px; transform: translate(0px, 18px);" data-popper-placement="bottom-end">
                            <a class="dropdown-item" href="">Lihat</a>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="h1 mb-3"> DAFTAR BUKU </div>
                    <div class="d-flex mb-2">
                      <div><a href="index.php?page=tabel_buku">Lihat </a></div>

                    </div>
                    <div class="progress progress-sm">
                      <div class="progress-bar bg-primary" style="width: 75%" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" aria-label="75% Complete">
                        <span class="visually-hidden">75% Complete</span>
                      </div>
                    </div>
                  </div>
                </div>
    </div>

    <div class="col-sm-6 col-lg-3">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex align-items-center">
                      <div class="subheader">Menu CASE </div>
                      <div class="ms-auto lh-1">
                        <div class="dropdown">
                          <a class="dropdown-toggle text-muted" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Detil</a>
                          <div class="dropdown-menu dropdown-menu-end" style="position: absolute; inset: 0px 0px auto auto; margin: 0px; transform: translate(0px, 18px);" data-popper-placement="bottom-end">
                            <a class="dropdown-item" href="">Lihat</a>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="h1 mb-3"> CASE </div>
                    <div class="d-flex mb-2">
                      <div><a href="">Lihat </a></div>
  
                    </div>
                    <div class="progress progress-sm">
                      <div class="progress-bar bg-primary" style="width: 10%" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" aria-label="75% Complete">
                        <span class="visually-hidden">10% Complete</span>
                      </div>
                    </div>
                  </div>
                </div>
    </div>

    <div class="col-sm-6 col-lg-3">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex align-items-center">
                      <div class="subheader">Menu CASE </div>
                      <div class="ms-auto lh-1">
                        <div class="dropdown">
                          <a class="dropdown-toggle text-muted" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Detil</a>
                          <div class="dropdown-menu dropdown-menu-end" style="position: absolute; inset: 0px 0px auto auto; margin: 0px; transform: translate(0px, 18px);" data-popper-placement="bottom-end">
                            <a class="dropdown-item" href="">Lihat</a>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="h1 mb-3"> CASE </div>
                    <div class="d-flex mb-2">
                      <div><a href="">Lihat </a></div>

                    </div>
                    <div class="progress progress-sm">
                      <div class="progress-bar bg-primary" style="width: 10%" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" aria-label="75% Complete">
                        <span class="visually-hidden">10% Complete</span>
                      </div>
                    </div>
                  </div>
                </div>
    </div>
              
</html>