<?php  
  include "sambungkan.php";
  
?>



<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- CSS files -->
    <link href="../dist/css/tabler.min.css?1666304673" rel="stylesheet"/>
    <link href="../dist/css/tabler-flags.min.css?1666304673" rel="stylesheet"/>
    <link href="../dist/css/tabler-payments.min.css?1666304673" rel="stylesheet"/>
    <link href="../dist/css/tabler-vendors.min.css?1666304673" rel="stylesheet"/>
    <link href="../dist/css/demo.min.css?1666304673" rel="stylesheet"/>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../dist/solid.min.css">
    <style>
      @import url('https://rsms.me/inter/inter.css');
      :root {
      	--tblr-font-sans-serif: Inter, -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif;
      }
    </style>
    </head>
    <body>
    <script src="../dist/js/demo-theme.min.js?1666304673"></script>
    
        <nav class="navbar bg-body-tertiary">
            <div class="container-fluid">
              <span class="navbar-brand mb-0 h1">Data Buku</span>
            </div>
          </nav>
          <div class="container">
          <h1 class="mt-5"> Perpustakaan</h1>
          <figure>
            <blockquote class="blockquote">
              <p>Data buku di perpustakaan UMMI</p>
            </blockquote>
            <figcaption class="blockquote-footer">
              Pustakawan <cite title="Source Title">UMMI</cite>
            </figcaption>
          </figure>
          <button type="button" class="btn btn-primary">Tambah Buku</button>
          <div class="table-responsive">
            <table class="table align-middle table-bordered table-hover">
              <thead>
                <tr>
                  <th>id Buku</th>
                  <th>Kode Buku</th>
                  <th>Penulis</th>
                  <th>Judul Buku</th>
                  <th>Tahun Terbit</th>
                  <th>Stok</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>01</td>
                  <td>12345</td>
                  <td>Mett</td>
                  <td>Forbidden</td>
                  <td>2020</td>
                  <td>5</td>
                </tr>
                <tr class="align-bottom">
                  Available Books
                </tr>
              </tbody>
            </table>
          </div>
          </div>
    </body>
    </html>